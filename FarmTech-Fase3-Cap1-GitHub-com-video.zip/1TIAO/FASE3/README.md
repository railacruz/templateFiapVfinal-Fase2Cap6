# Fase 3

## Capítulo 1 — Etapas de uma Máquina Agrícola

- [FarmTech Solutions — documentação, dados, gráficos, código Python, SQL e evidências](CAP-1-ETAPAS-DE-UMA-MAQUINA-AGRICOLA/README.md)
